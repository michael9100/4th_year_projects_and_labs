<template>
  <div class="page-workflow">
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'workflow',
  components: {
  }
}
</script>

<style lang="scss" scoped>

</style>

