# To test out this website

## View Compiled Version
1. Open dist folder.
2. Open index.html in a browser such as Chrome.

## View Hosted Version Online
1. Open https://dist-ni83isfe0.now.sh/ 

## Project setup
```
npm install
```

### Compiles and hot-reloads
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```
